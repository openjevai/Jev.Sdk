# Planetfall — Floyd — Mythic

The station is dying and everyone else has gone. You are not alone, though: a small robot with a lot of opinions has decided to help. Get off the station.

A Jev world package. Play it with:

    Jev.Sdk.World.Play planetfall-floyd-mythic.zip

`world.md` is the world; everything the engine needs is inside it.
