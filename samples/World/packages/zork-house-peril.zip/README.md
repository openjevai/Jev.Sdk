# Zork — The White House — Peril

You are in front of a white house with a boarded front door. Below it lies the Great Underground Empire. Find the entrance, and get below.

A Jev world package. Play it with:

    Jev.Sdk.World.Play zork-house-peril.zip

`world.md` is the world; everything the engine needs is inside it.
