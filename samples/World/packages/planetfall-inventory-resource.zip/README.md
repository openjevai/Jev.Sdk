# Planetfall — The Stores — Resource

The station is being abandoned and the stores are open. You cannot carry much and the pod is leaving. Take what matters.

A Jev world package. Play it with:

    Jev.Sdk.World.Play planetfall-inventory-resource.zip

`world.md` is the world; everything the engine needs is inside it.
