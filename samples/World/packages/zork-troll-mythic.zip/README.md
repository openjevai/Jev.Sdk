# Zork — The Troll and the Torch — Mythic

A troll holds the bridge. It wants something, and you are carrying a torch that is burning down. Get across, one way or another.

A Jev world package. Play it with:

    Jev.Sdk.World.Play zork-troll-mythic.zip

`world.md` is the world; everything the engine needs is inside it.
