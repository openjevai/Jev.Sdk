# The Hobbit — Thorin's Company — Resource

You are a hobbit a long way from home, walking with thirteen dwarves and a wizard toward a mountain. Thorin does not think much of you. Get the company to the mountain.

A Jev world package. Play it with:

    Jev.Sdk.World.Play hobbit-thorin-resource.zip

`world.md` is the world; everything the engine needs is inside it.
