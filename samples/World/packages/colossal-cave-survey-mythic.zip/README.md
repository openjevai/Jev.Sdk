# Colossal Cave — The Survey — Mythic

You are not here for gold. You are here to map the cave. Three passages, and you need each one recorded before you leave.

A Jev world package. Play it with:

    Jev.Sdk.World.Play colossal-cave-survey-mythic.zip

`world.md` is the world; everything the engine needs is inside it.
