# The Hobbit — Riddles in the Dark — Mythic

You are alone in a tunnel under the mountains with something in the water that wants to play a game. Answer well, and it will show you out.

A Jev world package. Play it with:

    Jev.Sdk.World.Play hobbit-riddles-mythic.zip

`world.md` is the world; everything the engine needs is inside it.
