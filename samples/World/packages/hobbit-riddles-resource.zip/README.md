# The Hobbit — Riddles in the Dark — Resource

You are alone in a tunnel under the mountains with something in the water that wants to play a game. Answer well, and it will show you out.

A Jev world package. Play it with:

    Jev.Sdk.World.Play hobbit-riddles-resource.zip

`world.md` is the world; everything the engine needs is inside it.
