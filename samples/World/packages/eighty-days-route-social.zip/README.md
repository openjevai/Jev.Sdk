# 80 Days — The Route — Social

Eighty days, and a wager. You are in London with a valet, a case, and a decision about which way round the world to go. Get back to London inside the eighty days.

A Jev world package. Play it with:

    Jev.Sdk.World.Play eighty-days-route-social.zip

`world.md` is the world; everything the engine needs is inside it.
