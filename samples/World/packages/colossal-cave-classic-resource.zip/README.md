# Colossal Cave — The Classic Cut — Resource

You are at the mouth of a cave that swallows daylight. Somewhere inside is the treasure of the cave, and your lamp is the only thing standing between you and the dark. Get in, get the treasure, get out.

A Jev world package. Play it with:

    Jev.Sdk.World.Play colossal-cave-classic-resource.zip

`world.md` is the world; everything the engine needs is inside it.
