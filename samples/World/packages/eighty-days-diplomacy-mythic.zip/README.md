# 80 Days — The Passenger — Mythic

The same journey, but you are not the one paying: a diplomat's dispatch is in your case, and it has to reach London. The route is now a question of who you travel with.

A Jev world package. Play it with:

    Jev.Sdk.World.Play eighty-days-diplomacy-mythic.zip

`world.md` is the world; everything the engine needs is inside it.
