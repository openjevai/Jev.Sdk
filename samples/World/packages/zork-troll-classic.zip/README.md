# Zork — The Troll and the Torch — Classic

A troll holds the bridge. It wants something, and you are carrying a torch that is burning down. Get across, one way or another.

A Jev world package. Play it with:

    Jev.Sdk.World.Play zork-troll-classic.zip

`world.md` is the world; everything the engine needs is inside it.
